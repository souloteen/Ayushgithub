﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace PasswordCracker.Models
{
    public class BruteForce
    {
        private static readonly string Salt = "STATIC_SALT";
        private const string Chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

        public static async Task<(string, long)> CrackPasswordAsync(string encryptedPassword, int maxThreads, IProgress<int> progress)
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();

            string foundPassword = null;
            int totalAttempts = 0;

            await Task.Run(() =>
            {
                var parallelOptions = new ParallelOptions { MaxDegreeOfParallelism = maxThreads };
                Parallel.ForEach(GenerateAllPossiblePasswords(), parallelOptions, (password, state) =>
                {
                    System.Threading.Interlocked.Increment(ref totalAttempts);
                    if (PasswordEncryption.EncryptPassword(password) == encryptedPassword)
                    {
                        foundPassword = password;
                        state.Stop();
                    }
                    progress.Report(totalAttempts);
                });
            });

            stopwatch.Stop();
            return (foundPassword, stopwatch.ElapsedMilliseconds);
        }

        private static IEnumerable<string> GenerateAllPossiblePasswords()
        {
            var queue = new Queue<string>();
            queue.Enqueue("");

            while (queue.Count > 0)
            {
                string current = queue.Dequeue();

                foreach (char c in Chars)
                {
                    string next = current + c;
                    yield return next;
                    queue.Enqueue(next);
                }
            }
        }
    }
}
