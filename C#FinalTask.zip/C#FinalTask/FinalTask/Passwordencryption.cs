﻿namespace PasswordCracker.Models
{
    public static class PasswordEncryption
    {
        private static readonly string Salt = "STATIC_SALT"; // Use a more secure salt in production

        public static string EncryptPassword(string password)
        {
            using (var sha256 = System.Security.Cryptography.SHA256.Create())
            {
                var saltedPassword = password + Salt;
                byte[] bytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(saltedPassword));
                return System.Convert.ToBase64String(bytes);
            }
        }
    }
}
